import 'dotenv/config';
import { Telegraf, Markup } from 'telegraf';

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
if (!TOKEN) throw new Error('TELEGRAM_BOT_TOKEN is required');

const BASE = (process.env.NEURAL_MESH_URL || 'http://127.0.0.1:48686').replace(/\/$/, '');
const TIMEOUT = Number(process.env.REQUEST_TIMEOUT_MS || 90000);
const MAX_HISTORY = Number(process.env.MAX_HISTORY || 10);
const MAX_PER_MINUTE = Number(process.env.MAX_REQUESTS_PER_MINUTE || 8);
const MAX_PER_DAY = Number(process.env.MAX_REQUESTS_PER_DAY || 100);
const MAX_INPUT = Number(process.env.MAX_INPUT_CHARS || 6000);
const PUBLIC_NETWORK_STATS = String(process.env.PUBLIC_NETWORK_STATS || 'false').toLowerCase() === 'true';
const BOT_NAME = process.env.BOT_NAME || 'Neural Mesh AI';
const TERMS_TEXT = process.env.TERMS_TEXT || 'Используя бота, вы соглашаетесь не отправлять пароли, seed-фразы, приватные ключи и иную критически чувствительную информацию. Ответы ИИ могут содержать ошибки.';

const bot = new Telegraf(TOKEN);
const history = new Map();
const minuteBuckets = new Map();
const dailyBuckets = new Map();
const activeUsers = new Set();

function splitMessage(text, max=3900) {
  const out=[]; let s=String(text || '');
  while (s.length > max) {
    let cut=s.lastIndexOf('\n', max);
    if (cut < max*0.55) cut=max;
    out.push(s.slice(0,cut)); s=s.slice(cut).trimStart();
  }
  if (s) out.push(s);
  return out;
}

function getHistory(userId) {
  if (!history.has(userId)) history.set(userId, []);
  return history.get(userId);
}
function pushHistory(userId, role, content) {
  const h = getHistory(userId);
  h.push({ role, content });
  while (h.length > MAX_HISTORY * 2) h.shift();
}

function dayKey() { return new Date().toISOString().slice(0,10); }
function allowed(userId) {
  const now = Date.now();
  const m = minuteBuckets.get(userId) || [];
  const recent = m.filter(ts => now-ts < 60000);
  if (recent.length >= MAX_PER_MINUTE) return { ok:false, reason:'minute' };
  recent.push(now); minuteBuckets.set(userId, recent);

  const dk = dayKey();
  const d = dailyBuckets.get(userId);
  const current = d?.day === dk ? d.count : 0;
  if (current >= MAX_PER_DAY) return { ok:false, reason:'day' };
  dailyBuckets.set(userId, { day:dk, count:current+1 });
  return { ok:true, left: Math.max(0, MAX_PER_DAY-current-1) };
}

async function call(path, opts={}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT);
  try {
    const res = await fetch(`${BASE}${path}`, { ...opts, signal: controller.signal });
    const text = await res.text();
    let body; try { body = JSON.parse(text); } catch { body = { raw:text }; }
    if (!res.ok) throw new Error(body?.error || body?.message || `HTTP ${res.status}`);
    return body;
  } finally { clearTimeout(timer); }
}

async function replyLong(ctx, text) {
  for (const chunk of splitMessage(text)) await ctx.reply(chunk, { disable_web_page_preview:true });
}

const mainKeyboard = Markup.keyboard([
  ['🧠 Новый диалог', 'ℹ️ Помощь'],
  ['📊 Лимиты', '🔒 Privacy']
]).resize();

bot.start(async ctx => {
  const name = ctx.from?.first_name || 'друг';
  await ctx.reply(
    `Привет, ${name}! Я ${BOT_NAME}.\n\nНапиши вопрос обычным сообщением — я передам его в распределённую сеть ИИ.\n\nДля нового контекста используй «🧠 Новый диалог».`,
    mainKeyboard
  );
});

bot.command('new', async ctx => {
  history.delete(ctx.from.id);
  await ctx.reply('Новый диалог начат. Контекст предыдущего разговора очищен.', mainKeyboard);
});
bot.hears('🧠 Новый диалог', async ctx => {
  history.delete(ctx.from.id);
  await ctx.reply('Новый диалог начат.');
});

bot.command('help', ctx => ctx.reply([
  `${BOT_NAME} — пользовательский интерфейс распределённого ИИ.`,
  '',
  '/new — новый диалог',
  '/limits — текущие лимиты',
  '/terms — условия и privacy',
  PUBLIC_NETWORK_STATS ? '/network — публичная статистика сети' : '',
  '',
  'Просто напиши вопрос текстом. Для безопасности не отправляй seed-фразы, приватные ключи и пароли.'
].filter(Boolean).join('\n'), mainKeyboard));
bot.hears('ℹ️ Помощь', ctx => ctx.telegram.sendMessage(ctx.chat.id, 'Просто напиши мне вопрос. Для нового контекста нажми «🧠 Новый диалог».'));

bot.command('terms', ctx => ctx.reply(`🔒 Privacy & Terms\n\n${TERMS_TEXT}`));
bot.hears('🔒 Privacy', ctx => ctx.reply(`🔒 Privacy & Terms\n\n${TERMS_TEXT}`));

function limitText(userId) {
  const dk = dayKey();
  const d = dailyBuckets.get(userId);
  const used = d?.day === dk ? d.count : 0;
  return `📊 Лимиты\nДо ${MAX_PER_MINUTE} запросов в минуту\nДо ${MAX_PER_DAY} запросов в сутки\nИспользовано сегодня: ${used}\nОсталось: ${Math.max(0, MAX_PER_DAY-used)}`;
}
bot.command('limits', ctx => ctx.reply(limitText(ctx.from.id)));
bot.hears('📊 Лимиты', ctx => ctx.reply(limitText(ctx.from.id)));

if (PUBLIC_NETWORK_STATS) {
  bot.command('network', async ctx => {
    try {
      const x = await call('/api/explorer');
      const a = x.aggregate || x.summary || x;
      await ctx.reply([
        '🌐 Neural Mesh',
        `Активные нейроны: ${a.live ?? a.liveNodes ?? a.nodes ?? '—'}`,
        `GPU-ноды: ${a.gpuNodes ?? '—'}`,
        `CPU-ноды: ${a.cpuNodes ?? '—'}`,
        `Задач/мин: ${a.tasksPerMin ?? a.tasksPerMinute ?? '—'}`
      ].join('\n'));
    } catch { await ctx.reply('Статистика сети временно недоступна.'); }
  });
}

bot.on('text', async ctx => {
  const text = ctx.message.text?.trim();
  if (!text || text.startsWith('/') || ['🧠 Новый диалог','ℹ️ Помощь','📊 Лимиты','🔒 Privacy'].includes(text)) return;
  const userId = ctx.from.id;
  if (text.length > MAX_INPUT) return ctx.reply(`Сообщение слишком длинное. Максимум ${MAX_INPUT} символов.`);
  if (activeUsers.has(userId)) return ctx.reply('Предыдущий запрос ещё обрабатывается. Дождись ответа.');

  const lim = allowed(userId);
  if (!lim.ok) {
    return ctx.reply(lim.reason === 'minute' ? 'Слишком много запросов подряд. Попробуй через минуту.' : 'Суточный лимит запросов исчерпан.');
  }

  activeUsers.add(userId);
  const oldHistory = getHistory(userId).slice(-MAX_HISTORY*2);
  pushHistory(userId, 'user', text);
  const typing = setInterval(() => ctx.sendChatAction('typing').catch(()=>{}), 4000);

  try {
    await ctx.sendChatAction('typing');
    const data = await call('/api/chat', {
      method:'POST',
      headers:{ 'content-type':'application/json' },
      body:JSON.stringify({ message:text, history:oldHistory })
    });
    const answer = String(data?.answer || data?.content || data?.response || '').trim();
    if (!answer) throw new Error('empty response');
    pushHistory(userId, 'assistant', answer);
    await replyLong(ctx, answer);
  } catch (e) {
    const msg = e?.name === 'AbortError'
      ? 'Сеть сейчас отвечает дольше обычного. Попробуй ещё раз чуть позже.'
      : 'Сеть временно недоступна. Попробуй повторить запрос позже.';
    await ctx.reply(msg);
  } finally {
    clearInterval(typing);
    activeUsers.delete(userId);
  }
});

bot.catch((err) => console.error('[telegram-user-bot]', err));
await bot.launch();
console.log(`${BOT_NAME} user bot online → ${BASE}`);

const stop = signal => { bot.stop(signal); process.exit(0); };
process.once('SIGINT', () => stop('SIGINT'));
process.once('SIGTERM', () => stop('SIGTERM'));
