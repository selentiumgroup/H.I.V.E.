# Neural Mesh Telegram User Bot

Публичная пользовательская версия Telegram-бота для Neural Mesh. Не содержит wallet/admin/governance/operator-команд.

## Возможности

- обычный диалог с Neural Mesh через `/api/chat`;
- отдельная история для каждого Telegram-пользователя;
- `/new` для нового диалога;
- rate limit на минуту и сутки;
- один одновременный запрос на пользователя;
- ограничение размера входного сообщения;
- typing indicator и разбиение длинных ответов Telegram;
- безопасные пользовательские сообщения об ошибках без раскрытия внутренней инфраструктуры;
- `/terms` и privacy notice;
- опциональная публичная `/network` статистика.

## Что намеренно отсутствует

Нет команд отправки NRN, просмотра treasury wallet, validator/admin API, halt/resume, recovery, API-token управления или private-key функций.

## Установка

```bash
npm install
cp .env.example .env
npm start
```

Обязательные параметры:

```env
TELEGRAM_BOT_TOKEN=...
NEURAL_MESH_URL=http://127.0.0.1:48686
```

Для публичного сервиса настройте лимиты:

```env
MAX_REQUESTS_PER_MINUTE=8
MAX_REQUESTS_PER_DAY=100
MAX_HISTORY=10
MAX_INPUT_CHARS=6000
PUBLIC_NETWORK_STATS=false
```

## Команды пользователя

- `/start`
- `/new`
- `/help`
- `/limits`
- `/terms`
- `/network` — только если `PUBLIC_NETWORK_STATS=true`

## Архитектура

```text
Telegram user
   ↓
User Bot
   ↓
POST /api/chat
   ↓
Neural Mesh
   ↓
Distributed neurons
   ↓
answer
```

Для production рекомендуется запускать бота отдельно от публичного P2P-порта Neural Mesh и разрешать ему доступ только к HTTP API нужной gateway-ноды.
